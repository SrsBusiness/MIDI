// These line functions are alternative to the already implemented for us
// However, those draw lines that are not anti-aliased. These draw smoother
// looking lines

//****************************************************************************
// Xiaolin Wu's Line Algorithm:
// Algorithm: http://en.wikipedia.org/wiki/Xiaolin_Wu%27s_line_algorithm
// The example code used helper methods, and it's probably advisable that you
// do as well

int draw_wu_line();

//****************************************************************************
// Sub-pixel rendering:
// Demonstration of effect: http://en.wikipedia.org/wiki/Subpixel_rendering
// Rather than draw whole pixels, we draw only part of it ie. we turn on
// certain pixel colors. This is used to make fonts appear smoother

int draw_subpixel_line();

