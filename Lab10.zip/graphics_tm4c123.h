int draw_wu_line();
int draw_subpixel_line();
