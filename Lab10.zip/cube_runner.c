#include "LCD.h"

int main(){
    LCD_Init();
    LCD_ColorFill(convertColor(0,0,0));
    for(int i = 0; i < 100; i++){
        LCD_DrawPixelRGB(i, i, 255, 255, 255);
    }
    for(int i = 0; i < 99; i++){
        LCD_DrawPixelRGB(i+1, i, 127, 127, 127);
        LCD_DrawPixelRGB(i, i+1, 127, 127, 127);
    }
}
